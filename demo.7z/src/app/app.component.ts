import { Component,OnInit } from '@angular/core';
import { DemoService } from './demo.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
constructor(private caller:DemoService){}
data:string;
title = 'app'; 
uname:string
//age:any;
pname:string
invokeGet(){
this.caller.getLoad().subscribe((data:Data)=>this.data=data.msg);
// console.log(this.uname,this.age)
}

invokePost(){
console.log(this.uname);
this.caller.postLoad(this.uname).subscribe((data:User)=>console.log(data));

} 
ngOnInit(){
this.invokeGet();
this.invokePost();
}
}
interface Data{
msg:string
} 
interface User {
  uname:string
}
