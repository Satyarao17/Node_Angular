import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class DemoService {

  constructor(private httpCaller:HttpClient) { }
  getLoad(){
    return this.httpCaller.get("http://localhost:3000/rest/api/get",{})
  }
postLoad(ename:string){
  // console.log("ENAME"+ename);
  // console.log("EAGE"+eage);
   return this.httpCaller.
   post("http://localhost:3000/rest/api/post",{
     "name":ename
   
   })
  }
}
