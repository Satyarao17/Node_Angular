import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms'
import { NgModule } from '@angular/core';
import {HttpClientModule,HttpClient} from '@angular/common/http'; 
import { AppComponent } from './app.component';
import { CallingserviceService } from './callingservice.service';
@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [CallingserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
