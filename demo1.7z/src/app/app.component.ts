import { Component } from '@angular/core';
import{CallingserviceService} from './callingservice.service';
import { FormsModule }   from '@angular/forms';

import {User} from './user.interface'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo1';
    uname:string;
  age:string;
  datalist:User[] = [];
constructor(private serv:CallingserviceService){}

 
  ngOnInit(){
    this.invokeGet()
  }
invokeGet(){
  this.serv.getData().subscribe((data:User[])=>this.datalist = data)
}

invokePut(name:string, age:string){
  if(name==''||age==''||this.uname==''||this.age=='')
  {
    console.log("values are required ");
    return false;
  }
  this.serv.putData(`${name}/${age}?name=${this.uname}&age=${this.age}`).subscribe(data=>this.invokeGet())
}

invokeDelete(name:string, age:string){
  console.log(name,age)
  this.serv.deleteData(`${name}/${age}?name=${this.uname}&age=${this.age}`).subscribe(data=>this.invokeGet())
}

invokePost(){
  console.log(this.uname,this.age);
  if(this.uname==''||this.age=='')
  {
    console.log("values are required ");
    return false;
  }
  this.serv.postData(this.uname,this.age).subscribe((data)=>this.invokeGet());
  
}

  
}

