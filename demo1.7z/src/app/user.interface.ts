export interface User {
  name:string
  age:string
}