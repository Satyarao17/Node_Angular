import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs'
import { Component,OnInit } from '@angular/core';
import { FormsModule }   from '@angular/forms';
@Injectable({
  providedIn: 'root'
})
export class CallingserviceService {
public _url='http://localhost:3000/rest/api'

  constructor(private http:HttpClient) { }

getData():Observable<any>{
  return this.http.get<any>(`${this._url}/get`)
}
deleteData(params:string):Observable<any>{
  return this.http.delete<any>(`${this._url}/delete/${params}`,{})
}
putData(params:string):Observable<any>{
  return this.http.put<any>(`${this._url}/put/${params}`,{})
}

 postData(ename:string,eage:string):Observable<any>{
  console.log("EName "+ename);
  console.log("EAge "+eage);
  return this.http.post('http://localhost:3000/rest/api/post',{
    name:ename,
    age:eage
  })
}

}