import { TestBed, inject } from '@angular/core/testing';

import { CallingserviceService } from './callingservice.service';

describe('CallingserviceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CallingserviceService]
    });
  });

  it('should be created', inject([CallingserviceService], (service: CallingserviceService) => {
    expect(service).toBeTruthy();
  }));
});
